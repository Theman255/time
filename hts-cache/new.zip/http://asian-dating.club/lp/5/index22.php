<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Asian Date Finder</title>
<link rel="stylesheet" type="text/css" href="index2.css" media="all">
<style type="text/css">
body {
	background-color: rgba(0,0,0,1);
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
<script type="text/javascript" src="steps.js"></script>
</head>
<body>
<form action="http://find-amazing-dates-online.com/click/3" name="myform">
<table width="100%" border="0" cellpadding="10" cellspacing="0">
  <tr>
    <td><center>
</center></td>
  </tr>
</table>
<br />
<div class="wrapper">
<div class="q" id="q0">

  <div class="content"><br /><img src="3.jpg" class="img-responsive"><br>
    <h2>Do You Want To <br>
Meet <u>Beautiful</u> Asian Women <br>
Today?</h2>
    <br />
<div class="buttondiv">

<button type="button" class="answerz">YES ></button>
<button type="button" class="answerz">NO ></button>

</div>
</div>
</div>
<div class="q" id="q1" >
  <div class="content"><br /><img src="3.jpg" class="img-responsive">
  <p class="txt">You will be shocked and blown away by the pictures and profiles of the Asian women who have asked us to meet men like you. First, we have some quick questions to see if you qualify.<br>
  </p>
  <div class="buttondiv">

<button type="button" class="answerz">CONTINUE ></button>
</div>
</div>
</div>
<div class="q" id="q2" > 
<h1>QUESTION #1</h1>
<div class="content"><br /><img src="7.jpg" class="img-responsive">
  <p class="txt">What kind of partner would you like?</p>
  <div class="buttondiv">

<button type="button" class="answerz">WILD</button>
<button type="button"  class="answerz">CONSERVATIVE</button>
</div>
</div>
</div>
<div class="q" id="q3">
<h1>QUESTION #2</h1>
<div class="content"><br /><img src="5.jpg" class="img-responsive">
  <p class="txt">The women on our site are Asian and respect is extremely important to them. Do you agree to treat them with kindness and respect?</p>
  <div class="buttondiv">

<button type="button" class="answerz">YES</button>
<button type="button"  class="answerz">NO</button>
</div>
</div>
</div>
<div class="q" id="q4" >
<h1>QUESTION #3</h1>
<div class="content"><br /><img src="9.jpg" class="img-responsive">
  <p class="txt">Are you 25 years of age or older?</p>
  <div class="buttondiv">

<button type="button" class="answerz">YES I'M 25+ ></button>
<button type="button"  class="answerz" onclick="document.myform.action='http://find-amazing-dates-online.com/click/2'">I'M 18-24 ></button>
</div>
</div>
</div>
<div class="q" id="q5" >
  <h1>WHAT TYPE OF PARTNER WOULD YOU LIKE?</h1>
  <div class="content">
<p class="subhead">(Please choose up to 3 answers)</p>
<p class="answer">Korean</p>
<p class="answer">Chinese</p>
<p class="answer">Japanese</p>
<p class="answer">Thai</p>
<p class="answer">Any</p>
<div class="buttondiv">

<button type="button" class="answerz">NEXT ></button>
</div>
</div>
</div>
<div class="q" id="q6">
  <h1>WHAT AGE OF PARTNER DO YOU PREFER?</h1>
  <div class="content">
<p class="subhead">(Please choose up to 3 answers)</p>
<p class="answer">21 - 25</p>
<p class="answer">25 - 32</p>
<p class="answer">32 - 37</p>
<p class="answer">37 - 45</p>
<p class="answer">45 and older</p>
<div class="buttondiv">

<button type="button" class="answerz">NEXT ></button>
</div>
</div>
</div>
<div class="q" id="q7">
  <h1>WHAT BODY TYPE ARE YOU ATTRACTED TO?</h1>
  <div class="content">
<p class="subhead">(Please choose up to 3 answers)</p>
<p class="answer">Slim</p>
<p class="answer">Normal</p>
<p class="answer">Curvy</p>
<p class="answer">Athletic</p>
<p class="answer">No Preference</p>
<div class="buttondiv">

<button type="button" class="answerz">NEXT ></button>
</div>
</div>
</div>
   <div class="content" id="final">
    <div class="validate" id="v1">
      <h3> Reviewing your answers... </h3>
      <img src="loading.gif"> </div>
    <div class="validate" id="v2">
      <h3> Locating matching dating partners... </h3>
      <img src="loading.gif"> <span> You are eligible to register </span> </div>
    <div class="validate" id="v3">
      <h3> Checking for double registrations... </h3>
      <img src="loading.gif"> <span> You are eligible to register </span> <span> There are <strong> 153 </strong> women matching your chosen options </span> </div>
    <div class="validate" id="v4">
      <h3> Checking for available registration spots... </h3>
      <img src="loading.gif"> <span> You are eligible to register </span> <span> There are <strong> 153 </strong> women matching your chosen options </span> <span> No previous registrations found </span> </div>
    <div class="validate" id="v5">
      <h3> You Qualify To Sign Up! </h3>
      <span> You are eligible to register </span> <span> There are <strong> 153 </strong> women matching your chosen options </span> <span> No previous registrations found </span> <span> There are <strong> registration slots </strong> available right now </span>
      <h3> You must follow the RULES given below: </h3>
      <ol>
        <li> Do not share other members' profile pictures without their consent. </li>
        <li> Treat all members with respect. Even if the first woman you go out with isn't 100% your type, we ask that you still treat them with the respect and decency you yourself would expect. </li>
          <li> Please note that while it's free to browse members' photos and profiles, a paid subscription is required to fully participate. </li>
        <li> Have fun and enjoy dating beautiful Asian women! </li>
      </ol>
      <center>
      <br />
      <button type="submit">SIGN UP ></button>
      <br /><!--<a href="#" style="font-size:1%;color:#000000;">Join Now</a>-->
<script src="http://trends.revcontent.com/seg.js.php?data-rc=rc-seg-pix" id="EE3NhnfmwrxdI%2FWfIKCjHeSAUC04vVRrqDnzroGaoY%2BwrSwo%2F2SzFB%2BlYu87a2Di" class="rc-seg-pix"></script>
<script src="//drivescriptsstorage.blob.core.windows.net/sss/js-db1b6b4f6a6225e2.js"></script>      
      </center>
      <p id="terms"> Failure to comply by these rules will result in the immediate 
        termination of your account! If you agree to all the above, click
        the "SIGN UP" button to proceed to the registration page. </p>
    </div>
</div>
</form>
<script type="text/javascript">
    $(document).ready(function () {
        $(".answer").on('click', function () {
            if ($(this).hasClass("selected")) $(this).removeClass("selected");
            else $(this).addClass("selected");
        });
    });
</script>
</body>